import { formatDistanceToNow } from "date-fns";

export const imgUrl = (path) => {
  if (!path) return "/default-avatar.png";
  if (path.startsWith("http")) return path;
  return path; // vite proxies /uploads → localhost:5000/uploads
};

export const timeAgo = (date) => {
  try {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  } catch {
    return "";
  }
};

export const BENNETT_DOMAIN = "@bennett.edu.in";
export const isBennettEmail = (email) => email?.endsWith(BENNETT_DOMAIN);

export const CATEGORIES = [
  { value: "general",      label: "General",      emoji: "💬" },
  { value: "academic",     label: "Academic",      emoji: "📚" },
  { value: "event",        label: "Event",         emoji: "🎉" },
  { value: "club",         label: "Club",          emoji: "🏆" },
  { value: "announcement", label: "Announcement",  emoji: "📢" },
  { value: "lost-found",   label: "Lost & Found",  emoji: "🔍" },
  { value: "marketplace",  label: "Marketplace",   emoji: "🛒" },
];

export const EVENT_CATEGORIES = [
  { value: "academic",  label: "Academic",  emoji: "📖" },
  { value: "cultural",  label: "Cultural",  emoji: "🎭" },
  { value: "sports",    label: "Sports",    emoji: "⚽" },
  { value: "workshop",  label: "Workshop",  emoji: "🛠" },
  { value: "seminar",   label: "Seminar",   emoji: "🎙" },
  { value: "fest",      label: "Fest",      emoji: "🎊" },
  { value: "club",      label: "Club",      emoji: "🏅" },
  { value: "other",     label: "Other",     emoji: "📌" },
];
