import { useState, useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import PageLayout from "../components/PageLayout";
import PostCard from "../components/PostCard";
import { getMe, updateProfile, updateProfilePic, updateCoverPic, changePassword } from "../services/authService";
import { getUserProfile, getUserPosts, followUser, unfollowUser } from "../services/userService";
import useAuthStore from "../store/useAuthStore";
import { imgUrl } from "../utils/helpers";
import toast from "react-hot-toast";

export default function Profile() {
  const { id } = useParams();
  const { user: currentUser, updateUser } = useAuthStore();
  const isOwnProfile = !id || id === currentUser?._id;

  const [profile, setProfile] = useState(null);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("posts");
  const [editOpen, setEditOpen] = useState(false);
  const [passOpen, setPassOpen] = useState(false);
  const [editForm, setEditForm] = useState({});
  const [passForm, setPassForm] = useState({ currentPassword: "", newPassword: "" });
  const [saving, setSaving] = useState(false);
  const profilePicRef = useRef(null);
  const coverPicRef = useRef(null);

  useEffect(() => {
    setLoading(true);
    const fetchProfile = isOwnProfile
      ? getMe().then((u) => ({ user: u, isFollowing: false, followersCount: u.followers?.length, followingCount: u.following?.length }))
      : getUserProfile(id);

    fetchProfile
      .then((data) => {
        setProfile(data);
        setEditForm({ name: data.user?.name, bio: data.user?.bio, department: data.user?.department, year: data.user?.year });
      })
      .catch(() => toast.error("Could not load profile"))
      .finally(() => setLoading(false));

    const uid = isOwnProfile ? currentUser?._id : id;
    if (uid) {
      getUserPosts(uid).then((d) => setPosts(d.posts || [])).catch(() => {});
    }
  }, [id]);

  const handleSaveProfile = async () => {
    setSaving(true);
    try {
      const updated = await updateProfile(editForm);
      updateUser(updated);
      setProfile((p) => ({ ...p, user: updated }));
      toast.success("Profile updated");
      setEditOpen(false);
    } catch { toast.error("Could not update profile"); }
    finally { setSaving(false); }
  };

  const handleProfilePic = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const form = new FormData();
    form.append("image", file);
    try {
      const res = await updateProfilePic(form);
      updateUser({ profilePic: res.profilePic });
      setProfile((p) => ({ ...p, user: { ...p.user, profilePic: res.profilePic } }));
      toast.success("Profile picture updated");
    } catch { toast.error("Upload failed"); }
  };

  const handleCoverPic = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const form = new FormData();
    form.append("image", file);
    try {
      const res = await updateCoverPic(form);
      updateUser({ coverPic: res.coverPic });
      setProfile((p) => ({ ...p, user: { ...p.user, coverPic: res.coverPic } }));
      toast.success("Cover updated");
    } catch { toast.error("Upload failed"); }
  };

  const handleChangePassword = async () => {
    if (passForm.newPassword.length < 6) { toast.error("New password must be at least 6 characters"); return; }
    setSaving(true);
    try {
      await changePassword(passForm);
      toast.success("Password changed!");
      setPassOpen(false);
      setPassForm({ currentPassword: "", newPassword: "" });
    } catch (err) { toast.error(err.response?.data?.message || "Failed to change password"); }
    finally { setSaving(false); }
  };

  const handleFollow = async () => {
    try {
      if (profile.isFollowing) {
        await unfollowUser(id);
        setProfile((p) => ({ ...p, isFollowing: false, followersCount: p.followersCount - 1 }));
      } else {
        await followUser(id);
        setProfile((p) => ({ ...p, isFollowing: true, followersCount: p.followersCount + 1 }));
      }
    } catch { toast.error("Could not update follow"); }
  };

  if (loading) {
    return (
      <PageLayout>
        <div className="space-y-4 animate-pulse-soft">
          <div className="card h-40 bg-slate-200 dark:bg-slate-700 rounded-2xl" />
          <div className="card p-5 flex gap-4">
            <div className="w-20 h-20 rounded-full bg-slate-200 dark:bg-slate-700" />
            <div className="flex-1 space-y-2 pt-2">
              <div className="w-40 h-4 bg-slate-200 dark:bg-slate-700 rounded" />
              <div className="w-28 h-3 bg-slate-100 dark:bg-slate-800 rounded" />
            </div>
          </div>
        </div>
      </PageLayout>
    );
  }

  const u = profile?.user;
  if (!u) return <PageLayout><div className="card p-8 text-center text-slate-400">User not found</div></PageLayout>;

  return (
    <PageLayout>
      <div className="space-y-4">
        {/* Cover */}
        <div className="relative rounded-2xl overflow-hidden bg-gradient-to-br from-brand-400 to-brand-700 h-44 group">
          {u.coverPic && (
            <img src={imgUrl(u.coverPic)} className="w-full h-full object-cover" onError={(e) => (e.target.style.display = "none")} />
          )}
          {isOwnProfile && (
            <>
              <button
                onClick={() => coverPicRef.current?.click()}
                className="absolute bottom-3 right-3 btn-secondary text-xs opacity-0 group-hover:opacity-100 transition-opacity"
              >
                📷 Change Cover
              </button>
              <input ref={coverPicRef} type="file" accept="image/*" onChange={handleCoverPic} className="hidden" />
            </>
          )}
        </div>

        {/* Profile info card */}
        <div className="card p-5 -mt-12 relative">
          <div className="flex items-end justify-between mb-4">
            {/* Avatar */}
            <div className="relative group">
              <img
                src={imgUrl(u.profilePic)}
                className="w-20 h-20 avatar ring-4 ring-white dark:ring-slate-900 border-2 border-slate-100 dark:border-slate-800"
                onError={(e) => (e.target.src = "/default-avatar.png")}
              />
              {isOwnProfile && (
                <>
                  <button
                    onClick={() => profilePicRef.current?.click()}
                    className="absolute inset-0 rounded-full bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white text-xs font-medium"
                  >
                    📷
                  </button>
                  <input ref={profilePicRef} type="file" accept="image/*" onChange={handleProfilePic} className="hidden" />
                </>
              )}
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2 pb-1">
              {isOwnProfile ? (
                <>
                  <button onClick={() => setEditOpen(true)} className="btn-secondary text-xs">Edit Profile</button>
                  <button onClick={() => setPassOpen(true)} className="btn-ghost text-xs">🔒 Password</button>
                </>
              ) : (
                <button
                  onClick={handleFollow}
                  className={`px-4 py-2 rounded-xl text-sm font-semibold transition-all ${
                    profile.isFollowing
                      ? "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300"
                      : "bg-brand-500 text-white hover:bg-brand-600 shadow-sm"
                  }`}
                >
                  {profile.isFollowing ? "Following" : "Follow"}
                </button>
              )}
            </div>
          </div>

          <div>
            <h2 className="font-display font-bold text-xl text-slate-900 dark:text-white">{u.name}</h2>
            <p className="text-sm text-slate-400">@{u.username}</p>

            {(u.department || u.year) && (
              <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
                🎓 {[u.department, u.year].filter(Boolean).join(" · ")}
              </p>
            )}

            {u.bio && <p className="text-sm text-slate-600 dark:text-slate-400 mt-2 leading-relaxed">{u.bio}</p>}

            {/* Stats */}
            <div className="flex gap-6 mt-4 pt-4 border-t border-slate-100 dark:border-slate-800">
              {[
                ["Posts", posts.length],
                ["Followers", profile.followersCount || u.followers?.length || 0],
                ["Following", profile.followingCount || u.following?.length || 0],
              ].map(([label, val]) => (
                <div key={label}>
                  <p className="font-display font-bold text-lg text-slate-900 dark:text-white leading-none">{val}</p>
                  <p className="text-xs text-slate-400 mt-0.5">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Posts grid */}
        <div className="card overflow-hidden">
          <div className="flex border-b border-slate-100 dark:border-slate-800">
            <button
              onClick={() => setTab("posts")}
              className={`flex-1 py-3 text-sm font-semibold transition-colors ${
                tab === "posts" ? "text-brand-600 border-b-2 border-brand-500" : "text-slate-500"
              }`}
            >
              📸 Posts
            </button>
          </div>

          {posts.length === 0 ? (
            <div className="p-12 text-center">
              <div className="text-4xl mb-3">📷</div>
              <p className="text-sm text-slate-400">No posts yet</p>
            </div>
          ) : (
            <div className="grid grid-cols-3 gap-0.5 p-0.5">
              {posts.map((post) => (
                <div key={post._id} className="relative aspect-square overflow-hidden bg-slate-100 dark:bg-slate-800 group cursor-pointer">
                  {post.image ? (
                    <img src={imgUrl(post.image)} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      onError={(e) => (e.target.style.display = "none")} />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center p-2">
                      <p className="text-xs text-slate-500 text-center line-clamp-4">{post.caption}</p>
                    </div>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3 text-white text-sm font-semibold">
                    <span>❤️ {post.likes?.length || 0}</span>
                    <span>💬 {post.comments?.length || 0}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Edit Profile Modal */}
      {editOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="card w-full max-w-md animate-pop">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-display font-semibold">Edit Profile</h3>
              <button onClick={() => setEditOpen(false)} className="btn-ghost p-1.5">
                <XIcon className="w-4 h-4" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div>
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Display Name</label>
                <input value={editForm.name || ""} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="input" />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Bio</label>
                <textarea value={editForm.bio || ""} onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                  rows={3} maxLength={200} className="input resize-none" placeholder="Tell people about yourself..." />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Department</label>
                  <input value={editForm.department || ""} onChange={(e) => setEditForm({ ...editForm, department: e.target.value })} className="input text-sm" />
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Year</label>
                  <input value={editForm.year || ""} onChange={(e) => setEditForm({ ...editForm, year: e.target.value })} className="input text-sm" />
                </div>
              </div>
            </div>
            <div className="px-5 py-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <button onClick={() => setEditOpen(false)} className="btn-secondary">Cancel</button>
              <button onClick={handleSaveProfile} disabled={saving} className="btn-primary">
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Change Password Modal */}
      {passOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="card w-full max-w-sm animate-pop">
            <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
              <h3 className="font-display font-semibold">Change Password</h3>
              <button onClick={() => setPassOpen(false)} className="btn-ghost p-1.5"><XIcon className="w-4 h-4" /></button>
            </div>
            <div className="p-5 space-y-3">
              <div>
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">Current Password</label>
                <input type="password" value={passForm.currentPassword}
                  onChange={(e) => setPassForm({ ...passForm, currentPassword: e.target.value })} className="input" />
              </div>
              <div>
                <label className="text-xs font-semibold text-slate-500 mb-1.5 block">New Password</label>
                <input type="password" value={passForm.newPassword}
                  onChange={(e) => setPassForm({ ...passForm, newPassword: e.target.value })} className="input" />
              </div>
            </div>
            <div className="px-5 py-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <button onClick={() => setPassOpen(false)} className="btn-secondary">Cancel</button>
              <button onClick={handleChangePassword} disabled={saving} className="btn-primary">
                {saving ? "Saving..." : "Update Password"}
              </button>
            </div>
          </div>
        </div>
      )}
    </PageLayout>
  );
}

function XIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>;
}
