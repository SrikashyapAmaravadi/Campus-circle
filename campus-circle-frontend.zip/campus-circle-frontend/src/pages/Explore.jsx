import { useState, useEffect } from "react";
import PageLayout from "../components/PageLayout";
import { searchUsers, followUser, unfollowUser } from "../services/userService";
import { searchPosts } from "../services/postService";
import PostCard from "../components/PostCard";
import { imgUrl } from "../utils/helpers";
import { Link } from "react-router-dom";
import toast from "react-hot-toast";

export default function Explore() {
  const [query, setQuery] = useState("");
  const [tab, setTab] = useState("people"); // people | posts
  const [users, setUsers] = useState([]);
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const delay = setTimeout(() => {
      if (query.trim().length > 0) doSearch();
      else { setUsers([]); setPosts([]); }
    }, 350);
    return () => clearTimeout(delay);
  }, [query, tab]);

  const doSearch = async () => {
    setLoading(true);
    try {
      if (tab === "people") {
        const data = await searchUsers(query);
        setUsers(data.users || []);
      } else {
        const data = await searchPosts(query);
        setPosts(data.posts || []);
      }
    } catch { toast.error("Search failed"); }
    finally { setLoading(false); }
  };

  const toggleFollow = async (id) => {
    const u = users.find((x) => x._id === id);
    try {
      if (u.isFollowing) await unfollowUser(id);
      else await followUser(id);
      setUsers((prev) => prev.map((x) => x._id === id ? { ...x, isFollowing: !x.isFollowing } : x));
    } catch { toast.error("Could not update"); }
  };

  return (
    <PageLayout>
      <div className="space-y-4">
        {/* Search input */}
        <div className="relative">
          <SearchIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search students, posts, hashtags..."
            className="input pl-10 py-3"
            autoFocus
          />
          {query && (
            <button onClick={() => setQuery("")} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
              <XIcon className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-white dark:bg-slate-900 rounded-xl p-1 shadow-card">
          {["people", "posts"].map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${
                tab === t ? "bg-brand-500 text-white shadow-sm" : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
              }`}
            >
              {t === "people" ? "👥 People" : "📸 Posts"}
            </button>
          ))}
        </div>

        {/* Results */}
        {loading ? (
          <div className="card p-8 text-center">
            <SpinIcon className="w-6 h-6 animate-spin mx-auto text-brand-500" />
            <p className="text-sm text-slate-400 mt-2">Searching...</p>
          </div>
        ) : query.trim() === "" ? (
          <div className="card p-10 text-center">
            <div className="text-5xl mb-3">🔍</div>
            <h3 className="font-display font-semibold text-slate-700 dark:text-slate-300 mb-1">
              Search Campus Circle
            </h3>
            <p className="text-sm text-slate-400">
              Find students, faculty, posts, and more.
            </p>
          </div>
        ) : tab === "people" ? (
          users.length === 0 ? (
            <div className="card p-8 text-center text-sm text-slate-400">No students found for "{query}"</div>
          ) : (
            <div className="space-y-3">
              {users.map((u) => (
                <div key={u._id} className="card p-4 flex items-center gap-3 hover:shadow-card-hover transition-shadow">
                  <Link to={`/profile/${u._id}`}>
                    <img src={imgUrl(u.profilePic)} className="w-12 h-12 avatar ring-2 ring-white dark:ring-slate-800"
                      onError={(e) => (e.target.src = "/default-avatar.png")} />
                  </Link>
                  <div className="flex-1 min-w-0">
                    <Link to={`/profile/${u._id}`}>
                      <p className="font-semibold text-sm hover:text-brand-600 transition-colors">{u.name}</p>
                    </Link>
                    <p className="text-xs text-slate-400">@{u.username}</p>
                    {u.department && <p className="text-xs text-slate-500 mt-0.5">{u.department} · {u.year}</p>}
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-slate-400">{u.followers?.length || 0} followers</span>
                    <button
                      onClick={() => toggleFollow(u._id)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                        u.isFollowing
                          ? "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                          : "bg-brand-500 text-white hover:bg-brand-600"
                      }`}
                    >
                      {u.isFollowing ? "Following" : "Follow"}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          posts.length === 0 ? (
            <div className="card p-8 text-center text-sm text-slate-400">No posts found for "{query}"</div>
          ) : (
            <div className="space-y-4">
              {posts.map((p) => (
                <PostCard key={p._id} post={p} onDelete={(id) => setPosts((prev) => prev.filter((x) => x._id !== id))} />
              ))}
            </div>
          )
        )}
      </div>
    </PageLayout>
  );
}

function SearchIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path strokeLinecap="round" d="M21 21l-4.35-4.35"/></svg>;
}
function XIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>;
}
function SpinIcon({ className }) {
  return <svg className={className} fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>;
}
