import { useState, useEffect } from "react";
import PageLayout from "../components/PageLayout";
import PostCard from "../components/PostCard";
import { getSavedPosts } from "../services/userService";
import toast from "react-hot-toast";

export default function Saved() {
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getSavedPosts()
      .then(setPosts)
      .catch(() => toast.error("Could not load saved posts"))
      .finally(() => setLoading(false));
  }, []);

  return (
    <PageLayout>
      <div className="mb-5">
        <h1 className="font-display font-bold text-2xl text-slate-900 dark:text-white">Saved Posts</h1>
        <p className="text-sm text-slate-500 mt-0.5">{posts.length} saved post{posts.length !== 1 ? "s" : ""}</p>
      </div>

      {loading ? (
        <div className="space-y-4">
          {[1, 2].map((i) => (
            <div key={i} className="card p-4 animate-pulse-soft">
              <div className="flex gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700" />
                <div className="space-y-1.5">
                  <div className="w-32 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
                  <div className="w-20 h-2.5 bg-slate-100 dark:bg-slate-800 rounded" />
                </div>
              </div>
              <div className="w-full h-40 bg-slate-100 dark:bg-slate-800 rounded-xl" />
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-3">🔖</div>
          <h3 className="font-display font-semibold text-lg mb-1">No saved posts yet</h3>
          <p className="text-sm text-slate-400">Bookmark posts by tapping the save icon.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard
              key={post._id}
              post={post}
              onDelete={(id) => setPosts((prev) => prev.filter((p) => p._id !== id))}
            />
          ))}
        </div>
      )}
    </PageLayout>
  );
}
