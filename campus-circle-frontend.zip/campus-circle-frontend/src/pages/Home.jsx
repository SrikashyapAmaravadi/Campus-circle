import { useState, useEffect, useCallback } from "react";
import PageLayout from "../components/PageLayout";
import PostCard from "../components/PostCard";
import { getFeed, getPosts } from "../services/postService";
import { CATEGORIES } from "../utils/helpers";
import useAuthStore from "../store/useAuthStore";
import toast from "react-hot-toast";

export default function Home() {
  const { user } = useAuthStore();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("feed"); // feed | explore
  const [category, setCategory] = useState("all");
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [newPost, setNewPost] = useState(null);

  const fetchPosts = useCallback(async (reset = false) => {
    const p = reset ? 1 : page;
    setLoading(true);
    try {
      let data;
      if (tab === "feed") {
        data = await getFeed(p);
      } else {
        const qs = `${p}${category !== "all" ? `&category=${category}` : ""}`;
        data = await getPosts(qs);
      }
      const newPosts = data.posts || [];
      setPosts((prev) => reset ? newPosts : [...prev, ...newPosts]);
      setHasMore(p < (data.pages || 1));
      if (reset) setPage(1);
    } catch {
      toast.error("Could not load posts");
    } finally {
      setLoading(false);
    }
  }, [tab, category, page]);

  useEffect(() => { fetchPosts(true); }, [tab, category]);

  const handlePostCreated = (post) => {
    setPosts((prev) => [post, ...prev]);
  };

  const handleDeletePost = (id) => {
    setPosts((prev) => prev.filter((p) => p._id !== id));
  };

  const loadMore = () => {
    setPage((p) => p + 1);
    fetchPosts(false);
  };

  return (
    <PageLayout onPostCreated={handlePostCreated}>
      {/* Feed / Explore Tabs */}
      <div className="flex items-center gap-1 mb-5 bg-white dark:bg-slate-900 rounded-xl p-1 shadow-card">
        {["feed", "explore"].map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all duration-150 ${
              tab === t
                ? "bg-brand-500 text-white shadow-sm"
                : "text-slate-500 hover:text-slate-700 dark:hover:text-slate-300"
            }`}
          >
            {t === "feed" ? "🏠 My Feed" : "🌐 Explore"}
          </button>
        ))}
      </div>

      {/* Category filter (explore only) */}
      {tab === "explore" && (
        <div className="flex gap-2 mb-5 overflow-x-auto pb-1 scrollbar-hide">
          <button
            onClick={() => setCategory("all")}
            className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-150 ${
              category === "all"
                ? "bg-brand-500 text-white"
                : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-brand-300"
            }`}
          >
            All
          </button>
          {CATEGORIES.map((c) => (
            <button
              key={c.value}
              onClick={() => setCategory(c.value)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all duration-150 ${
                category === c.value
                  ? "bg-brand-500 text-white"
                  : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-400 hover:border-brand-300"
              }`}
            >
              {c.emoji} {c.label}
            </button>
          ))}
        </div>
      )}

      {/* Posts */}
      {loading && posts.length === 0 ? (
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="card p-4 animate-pulse-soft">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-slate-200 dark:bg-slate-700" />
                <div className="space-y-1.5">
                  <div className="w-32 h-3 bg-slate-200 dark:bg-slate-700 rounded" />
                  <div className="w-20 h-2.5 bg-slate-100 dark:bg-slate-800 rounded" />
                </div>
              </div>
              <div className="w-full h-52 bg-slate-100 dark:bg-slate-800 rounded-xl" />
            </div>
          ))}
        </div>
      ) : posts.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-4">
            {tab === "feed" ? "👋" : "🔭"}
          </div>
          <h3 className="font-display font-semibold text-lg text-slate-800 dark:text-white mb-2">
            {tab === "feed" ? "Your feed is empty" : "Nothing here yet"}
          </h3>
          <p className="text-sm text-slate-500 mb-4">
            {tab === "feed"
              ? "Follow some students to see their posts here."
              : "Be the first to post something!"}
          </p>
          {tab === "feed" && (
            <button onClick={() => setTab("explore")} className="btn-primary">
              Explore posts
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-4">
          {posts.map((post) => (
            <PostCard
              key={post._id}
              post={post}
              onDelete={handleDeletePost}
            />
          ))}
          {hasMore && (
            <button
              onClick={loadMore}
              disabled={loading}
              className="btn-secondary w-full"
            >
              {loading ? "Loading..." : "Load more"}
            </button>
          )}
        </div>
      )}
    </PageLayout>
  );
}
