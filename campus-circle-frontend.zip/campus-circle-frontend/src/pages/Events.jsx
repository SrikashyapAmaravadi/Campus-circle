import { useState, useEffect } from "react";
import PageLayout from "../components/PageLayout";
import { getEvents, attendEvent, unattendEvent } from "../services/eventService";
import { EVENT_CATEGORIES, imgUrl, timeAgo } from "../utils/helpers";
import { format, isPast } from "date-fns";
import useAuthStore from "../store/useAuthStore";
import toast from "react-hot-toast";

export default function Events() {
  const { user } = useAuthStore();
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("upcoming"); // upcoming | all
  const [category, setCategory] = useState("all");

  useEffect(() => {
    const qs = `?${filter === "upcoming" ? "upcoming=true&" : ""}${category !== "all" ? `category=${category}` : ""}`;
    setLoading(true);
    getEvents(qs)
      .then((d) => setEvents(d.events || []))
      .catch(() => toast.error("Could not load events"))
      .finally(() => setLoading(false));
  }, [filter, category]);

  const handleRSVP = async (ev) => {
    const isAttending = ev.attendees?.some((a) => (a._id || a) === user?._id);
    try {
      if (isAttending) {
        await unattendEvent(ev._id);
        toast.success("Registration cancelled");
      } else {
        await attendEvent(ev._id);
        toast.success("You're going! 🎉");
      }
      setEvents((prev) =>
        prev.map((e) =>
          e._id === ev._id
            ? {
                ...e,
                attendees: isAttending
                  ? e.attendees.filter((a) => (a._id || a) !== user?._id)
                  : [...(e.attendees || []), { _id: user?._id }],
              }
            : e
        )
      );
    } catch (err) {
      toast.error(err.response?.data?.message || "Could not update RSVP");
    }
  };

  const categoryEmoji = (cat) => EVENT_CATEGORIES.find((c) => c.value === cat)?.emoji || "📌";

  return (
    <PageLayout hideRight>
      <div className="max-w-3xl mx-auto space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="font-display font-bold text-2xl text-slate-900 dark:text-white">Campus Events</h1>
            <p className="text-sm text-slate-500 mt-0.5">Discover what's happening at Bennett</p>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Upcoming / All */}
          <div className="flex gap-1 bg-white dark:bg-slate-900 rounded-xl p-1 shadow-card">
            {["upcoming", "all"].map((f) => (
              <button key={f} onClick={() => setFilter(f)}
                className={`flex-1 py-2 px-4 rounded-lg text-xs font-semibold capitalize transition-all ${
                  filter === f ? "bg-brand-500 text-white shadow-sm" : "text-slate-500 hover:text-slate-700"
                }`}>
                {f === "upcoming" ? "⏳ Upcoming" : "📋 All Events"}
              </button>
            ))}
          </div>

          {/* Category */}
          <div className="flex gap-2 overflow-x-auto pb-0.5 flex-1">
            <button onClick={() => setCategory("all")}
              className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                category === "all" ? "bg-brand-500 text-white" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-500 hover:border-brand-300"
              }`}>All</button>
            {EVENT_CATEGORIES.map((c) => (
              <button key={c.value} onClick={() => setCategory(c.value)}
                className={`flex-shrink-0 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                  category === c.value ? "bg-brand-500 text-white" : "bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-500 hover:border-brand-300"
                }`}>
                {c.emoji} {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Event list */}
        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="card p-5 animate-pulse-soft flex gap-4">
                <div className="w-14 h-14 rounded-xl bg-slate-200 dark:bg-slate-700 flex-shrink-0" />
                <div className="flex-1 space-y-2">
                  <div className="w-2/3 h-4 bg-slate-200 dark:bg-slate-700 rounded" />
                  <div className="w-1/2 h-3 bg-slate-100 dark:bg-slate-800 rounded" />
                  <div className="w-full h-3 bg-slate-100 dark:bg-slate-800 rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : events.length === 0 ? (
          <div className="card p-12 text-center">
            <div className="text-5xl mb-3">📅</div>
            <h3 className="font-display font-semibold text-lg mb-1">No events found</h3>
            <p className="text-sm text-slate-400">Check back soon for upcoming campus events.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {events.map((ev) => {
              const past = isPast(new Date(ev.date));
              const attending = ev.attendees?.some((a) => (a._id || a) === user?._id);
              const full = ev.maxAttendees && ev.attendees?.length >= ev.maxAttendees && !attending;

              return (
                <div key={ev._id} className={`card overflow-hidden hover:shadow-card-hover transition-shadow ${past ? "opacity-60" : ""}`}>
                  {/* Cover image if exists */}
                  {ev.coverImage && (
                    <div className="h-36 overflow-hidden bg-slate-100 dark:bg-slate-800">
                      <img src={imgUrl(ev.coverImage)} className="w-full h-full object-cover" />
                    </div>
                  )}
                  <div className="p-5 flex gap-4">
                    {/* Date block */}
                    <div className="flex-shrink-0 w-14 h-14 rounded-xl bg-brand-50 dark:bg-brand-950/40 flex flex-col items-center justify-center border border-brand-100 dark:border-brand-900">
                      <span className="text-[10px] text-brand-600 font-bold uppercase leading-none">
                        {format(new Date(ev.date), "MMM")}
                      </span>
                      <span className="text-xl font-bold text-brand-700 dark:text-brand-400 leading-tight">
                        {format(new Date(ev.date), "d")}
                      </span>
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <div>
                          <span className="tag text-[10px] mb-1 inline-block">
                            {categoryEmoji(ev.category)} {ev.category}
                          </span>
                          <h3 className="font-display font-semibold text-base text-slate-900 dark:text-white leading-snug">
                            {ev.title}
                          </h3>
                        </div>
                        {past && (
                          <span className="text-xs text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-full flex-shrink-0">
                            Past
                          </span>
                        )}
                      </div>

                      {ev.description && (
                        <p className="text-sm text-slate-500 dark:text-slate-400 mb-2 line-clamp-2">
                          {ev.description}
                        </p>
                      )}

                      <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                        <span className="flex items-center gap-1">
                          🕐 {format(new Date(ev.date), "h:mm a, MMM d yyyy")}
                        </span>
                        {ev.location && <span className="flex items-center gap-1">📍 {ev.location}</span>}
                        {ev.organizer && <span className="flex items-center gap-1">👤 {ev.organizer}</span>}
                        <span className="flex items-center gap-1">
                          👥 {ev.attendees?.length || 0}
                          {ev.maxAttendees ? ` / ${ev.maxAttendees}` : ""} going
                        </span>
                      </div>
                    </div>

                    {/* RSVP */}
                    {!past && (
                      <div className="flex-shrink-0">
                        <button
                          onClick={() => handleRSVP(ev)}
                          disabled={full}
                          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all duration-150 ${
                            attending
                              ? "bg-green-50 dark:bg-green-950/30 text-green-600 dark:text-green-400 border border-green-200 dark:border-green-800"
                              : full
                              ? "bg-slate-100 dark:bg-slate-800 text-slate-400 cursor-not-allowed"
                              : "bg-brand-500 text-white hover:bg-brand-600 shadow-sm"
                          }`}
                        >
                          {attending ? "✓ Going" : full ? "Full" : "RSVP"}
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </PageLayout>
  );
}
