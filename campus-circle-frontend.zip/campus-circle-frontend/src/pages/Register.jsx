import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { registerUser } from "../services/authService";
import useAuthStore from "../store/useAuthStore";
import { isBennettEmail } from "../utils/helpers";
import toast from "react-hot-toast";

const YEARS = ["1st Year", "2nd Year", "3rd Year", "4th Year", "Postgraduate", "PhD", "Faculty", "Staff"];
const DEPARTMENTS = [
  "Computer Science", "Computer Science & Engineering", "Information Technology",
  "Electronics & Communication", "Mechanical Engineering", "Civil Engineering",
  "Business Administration", "Law", "Media Studies", "Design", "Other",
];

export default function Register() {
  const [step, setStep] = useState(1);
  const [form, setForm] = useState({
    name: "", username: "", email: "", password: "",
    department: "", year: "",
  });
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading] = useState(false);
  const { setAuth } = useAuthStore();
  const navigate = useNavigate();

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const validateStep1 = () => {
    if (!form.name.trim()) { toast.error("Name is required"); return false; }
    if (!form.username.trim()) { toast.error("Username is required"); return false; }
    if (!/^[a-z0-9_.]+$/.test(form.username.toLowerCase())) {
      toast.error("Username: letters, numbers, dots, underscores only"); return false;
    }
    if (!isBennettEmail(form.email)) {
      toast.error("Only @bennett.edu.in emails are allowed"); return false;
    }
    if (form.password.length < 6) {
      toast.error("Password must be at least 6 characters"); return false;
    }
    return true;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const data = await registerUser({
        ...form,
        username: form.username.toLowerCase(),
      });
      setAuth(data, data.token);
      toast.success("Welcome to Campus Circle! 🎉");
      navigate("/", { replace: true });
    } catch (err) {
      toast.error(err.response?.data?.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0d0f14] flex">
      {/* Left — Branding */}
      <div className="hidden lg:flex flex-col justify-between w-[45%] bg-gradient-to-br from-brand-600 to-brand-800 p-12 relative overflow-hidden">
        <div className="absolute inset-0">
          <div className="absolute top-0 right-0 w-72 h-72 rounded-full bg-white/5 translate-x-1/2 -translate-y-1/2" />
          <div className="absolute bottom-0 left-0 w-72 h-72 rounded-full bg-white/5 -translate-x-1/2 translate-y-1/2" />
        </div>
        <div className="relative z-10 flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <span className="text-white font-bold font-display text-lg">CC</span>
          </div>
          <p className="text-white font-display font-bold text-xl">Campus Circle</p>
        </div>
        <div className="relative z-10 space-y-5">
          <h1 className="font-display text-4xl font-bold text-white leading-tight">
            Join your<br />campus network.
          </h1>
          <div className="space-y-3">
            {[
              ["🎓", "Student & faculty network", "Connect with the entire Bennett community"],
              ["📅", "Campus events", "Never miss a fest, seminar, or workshop"],
              ["📸", "Share moments", "Post your campus life for everyone to see"],
            ].map(([emoji, title, desc]) => (
              <div key={title} className="flex items-start gap-3">
                <span className="text-xl">{emoji}</span>
                <div>
                  <p className="text-white font-semibold text-sm">{title}</p>
                  <p className="text-white/60 text-xs">{desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
        <p className="relative z-10 text-white/40 text-xs">Exclusively for @bennett.edu.in accounts</p>
      </div>

      {/* Right — Form */}
      <div className="flex-1 flex items-center justify-center p-8">
        <div className="w-full max-w-md space-y-6 animate-fade-up">
          <div>
            <div className="flex items-center justify-between mb-1">
              <h2 className="font-display font-bold text-2xl text-slate-900 dark:text-white">Create account</h2>
              <span className="text-xs text-slate-400 font-medium">Step {step} of 2</span>
            </div>
            <div className="h-1 bg-slate-100 dark:bg-slate-800 rounded-full mt-3">
              <div
                className="h-1 bg-brand-500 rounded-full transition-all duration-500"
                style={{ width: step === 1 ? "50%" : "100%" }}
              />
            </div>
          </div>

          <form onSubmit={step === 1 ? (e) => { e.preventDefault(); if (validateStep1()) setStep(2); } : handleSubmit}
            className="space-y-4">
            {step === 1 ? (
              <>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Full Name</label>
                    <input value={form.name} onChange={(e) => set("name", e.target.value)}
                      placeholder="Rahul Sharma" required className="input" />
                  </div>
                  <div>
                    <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Username</label>
                    <div className="relative">
                      <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 text-sm">@</span>
                      <input value={form.username} onChange={(e) => set("username", e.target.value.toLowerCase())}
                        placeholder="rahul.sharma" required className="input pl-7" />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Bennett Email</label>
                  <div className="relative">
                    <input type="email" value={form.email} onChange={(e) => set("email", e.target.value)}
                      placeholder="yourname@bennett.edu.in" required className="input pl-10" />
                    <MailIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                  </div>
                  {form.email && !isBennettEmail(form.email) && (
                    <p className="text-xs text-red-500 mt-1">Must end with @bennett.edu.in</p>
                  )}
                  {form.email && isBennettEmail(form.email) && (
                    <p className="text-xs text-green-500 mt-1 flex items-center gap-1"><CheckIcon className="w-3 h-3" /> Valid Bennett email</p>
                  )}
                </div>

                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Password</label>
                  <div className="relative">
                    <input type={showPass ? "text" : "password"} value={form.password} onChange={(e) => set("password", e.target.value)}
                      placeholder="Min. 6 characters" required className="input pl-10 pr-10" />
                    <LockIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                    <button type="button" onClick={() => setShowPass(!showPass)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                      {showPass ? <EyeOffIcon className="w-4 h-4" /> : <EyeIcon className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <button type="submit" className="btn-primary w-full py-3 text-sm">Continue →</button>
              </>
            ) : (
              <>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Department</label>
                  <select value={form.department} onChange={(e) => set("department", e.target.value)} className="input">
                    <option value="">Select department</option>
                    {DEPARTMENTS.map((d) => <option key={d} value={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs font-semibold text-slate-600 dark:text-slate-400 mb-1.5 block">Year / Role</label>
                  <div className="grid grid-cols-4 gap-2">
                    {YEARS.map((y) => (
                      <button type="button" key={y} onClick={() => set("year", y)}
                        className={`py-2 px-1 rounded-xl border text-xs font-medium transition-all duration-150 ${
                          form.year === y
                            ? "border-brand-500 bg-brand-50 dark:bg-brand-950/40 text-brand-600 dark:text-brand-400"
                            : "border-slate-200 dark:border-slate-700 hover:border-brand-300 text-slate-600 dark:text-slate-400"
                        }`}>
                        {y}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <button type="button" onClick={() => setStep(1)} className="btn-secondary flex-1 py-3 text-sm">← Back</button>
                  <button type="submit" disabled={loading} className="btn-primary flex-1 py-3 text-sm">
                    {loading ? (
                      <span className="flex items-center justify-center gap-2">
                        <SpinIcon className="w-4 h-4 animate-spin" /> Creating...
                      </span>
                    ) : "Create Account 🎉"}
                  </button>
                </div>
              </>
            )}
          </form>

          <p className="text-center text-sm text-slate-500">
            Already have an account?{" "}
            <Link to="/login" className="text-brand-600 hover:text-brand-700 font-semibold">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

function MailIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>;
}
function LockIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><rect x="3" y="11" width="18" height="11" rx="2"/><path strokeLinecap="round" d="M7 11V7a5 5 0 0110 0v4"/></svg>;
}
function EyeIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>;
}
function EyeOffIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" d="M17.94 17.94A10.07 10.07 0 0112 20c-7 0-11-8-11-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c7 0 11 8 11 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24M1 1l22 22"/></svg>;
}
function CheckIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7"/></svg>;
}
function SpinIcon({ className }) {
  return <svg className={className} fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>;
}
