import { useState, useRef } from "react";
import { createPost } from "../services/postService";
import { CATEGORIES } from "../utils/helpers";
import toast from "react-hot-toast";

export default function CreatePostModal({ isOpen, onClose, onCreated }) {
  const [caption, setCaption] = useState("");
  const [image, setImage] = useState(null);
  const [preview, setPreview] = useState(null);
  const [category, setCategory] = useState("general");
  const [tags, setTags] = useState("");
  const [loading, setLoading] = useState(false);
  const fileRef = useRef(null);

  if (!isOpen) return null;

  const handleImage = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setImage(file);
    setPreview(URL.createObjectURL(file));
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      setImage(file);
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async () => {
    if (!caption.trim() && !image) {
      toast.error("Add a caption or image");
      return;
    }
    setLoading(true);
    try {
      const form = new FormData();
      if (image) form.append("image", image);
      form.append("caption", caption);
      form.append("category", category);
      form.append("tags", tags);

      const post = await createPost(form);
      toast.success("Post shared!");
      onCreated?.(post);
      handleClose();
    } catch (err) {
      toast.error(err.response?.data?.message || "Could not create post");
    } finally {
      setLoading(false);
    }
  };

  const handleClose = () => {
    setCaption(""); setImage(null); setPreview(null);
    setCategory("general"); setTags("");
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div className="card w-full max-w-lg animate-pop overflow-hidden" onClick={(e) => e.stopPropagation()}>
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-100 dark:border-slate-800">
          <h2 className="font-display font-semibold text-base">Create Post</h2>
          <button onClick={handleClose} className="btn-ghost p-1.5">
            <XIcon className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          {/* Image drop zone */}
          <div
            onDrop={handleDrop}
            onDragOver={(e) => e.preventDefault()}
            onClick={() => !preview && fileRef.current?.click()}
            className={`relative rounded-xl border-2 border-dashed transition-all duration-150 overflow-hidden
              ${preview ? "border-transparent" : "border-slate-200 dark:border-slate-700 hover:border-brand-400 cursor-pointer bg-slate-50 dark:bg-slate-800/50"}`}
          >
            {preview ? (
              <div className="relative">
                <img src={preview} className="w-full max-h-64 object-cover rounded-xl" />
                <button
                  onClick={(e) => { e.stopPropagation(); setImage(null); setPreview(null); }}
                  className="absolute top-2 right-2 w-7 h-7 bg-black/60 hover:bg-black/80 rounded-full flex items-center justify-center text-white transition-colors"
                >
                  <XIcon className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <div className="py-10 flex flex-col items-center gap-2 text-slate-400">
                <ImageIcon className="w-8 h-8" />
                <p className="text-sm font-medium">Drop an image or click to upload</p>
                <p className="text-xs">JPG, PNG, WebP — max 5MB</p>
              </div>
            )}
          </div>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleImage} className="hidden" />

          {/* Caption */}
          <textarea
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="What's on your mind?"
            rows={3}
            maxLength={1000}
            className="input resize-none"
          />

          {/* Category + Tags row */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 block">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="input py-2 text-xs"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.value} value={c.value}>{c.emoji} {c.label}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-slate-500 dark:text-slate-400 mb-1 block">Tags (comma-separated)</label>
              <input
                value={tags}
                onChange={(e) => setTags(e.target.value)}
                placeholder="exam, cs, tips"
                className="input py-2 text-xs"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
          <button onClick={handleClose} className="btn-secondary">Cancel</button>
          <button onClick={handleSubmit} disabled={loading} className="btn-primary">
            {loading ? (
              <span className="flex items-center gap-2">
                <SpinIcon className="w-4 h-4 animate-spin" /> Posting...
              </span>
            ) : "Share Post"}
          </button>
        </div>
      </div>
    </div>
  );
}

function XIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>;
}
function ImageIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={1.5} viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="8.5" cy="8.5" r="1.5"/><path strokeLinecap="round" strokeLinejoin="round" d="M21 15l-5-5L5 21"/></svg>;
}
function SpinIcon({ className }) {
  return <svg className={className} fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>;
}
