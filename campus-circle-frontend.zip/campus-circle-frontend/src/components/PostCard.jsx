import { useState } from "react";
import { Link } from "react-router-dom";
import { likePost, unlikePost, addComment, deleteComment, deletePost, toggleSave } from "../services/postService";
import useAuthStore from "../store/useAuthStore";
import { imgUrl, timeAgo, CATEGORIES } from "../utils/helpers";
import toast from "react-hot-toast";

export default function PostCard({ post, onDelete, onUpdate }) {
  const { user } = useAuthStore();
  const [likes, setLikes] = useState(post.likes || []);
  const [comments, setComments] = useState(post.comments || []);
  const [commentText, setCommentText] = useState("");
  const [showComments, setShowComments] = useState(false);
  const [saved, setSaved] = useState(false);
  const [loadingLike, setLoadingLike] = useState(false);
  const [showImage, setShowImage] = useState(false);

  const isLiked = likes.some((id) => id?.toString() === user?._id?.toString());
  const isOwner = post.user?._id === user?._id;
  const category = CATEGORIES.find((c) => c.value === post.category);

  const handleLike = async () => {
    if (loadingLike) return;
    setLoadingLike(true);
    try {
      if (isLiked) {
        const res = await unlikePost(post._id);
        setLikes((prev) => prev.filter((id) => id?.toString() !== user?._id?.toString()));
      } else {
        await likePost(post._id);
        setLikes((prev) => [...prev, user._id]);
      }
    } catch (err) {
      toast.error("Could not update like");
    } finally {
      setLoadingLike(false);
    }
  };

  const handleComment = async () => {
    if (!commentText.trim()) return;
    try {
      const updated = await addComment(post._id, commentText);
      setComments(updated.comments);
      setCommentText("");
    } catch {
      toast.error("Could not post comment");
    }
  };

  const handleDeleteComment = async (commentId) => {
    try {
      await deleteComment(post._id, commentId);
      setComments((prev) => prev.filter((c) => c._id !== commentId));
    } catch {
      toast.error("Could not delete comment");
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this post?")) return;
    try {
      await deletePost(post._id);
      toast.success("Post deleted");
      onDelete?.(post._id);
    } catch {
      toast.error("Could not delete post");
    }
  };

  const handleSave = async () => {
    try {
      const res = await toggleSave(post._id);
      setSaved(res.saved);
      toast.success(res.saved ? "Post saved" : "Post unsaved");
    } catch {
      toast.error("Could not save post");
    }
  };

  return (
    <article className="card overflow-hidden animate-fade-up hover:shadow-card-hover transition-shadow duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-4 pt-4 pb-3">
        <Link to={`/profile/${post.user?._id}`} className="flex items-center gap-3 group">
          <div className="relative">
            <img
              src={imgUrl(post.user?.profilePic)}
              className="w-10 h-10 avatar ring-2 ring-white dark:ring-slate-800"
              alt={post.user?.name}
              onError={(e) => (e.target.src = "/default-avatar.png")}
            />
            <span className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 bg-green-400 rounded-full border-2 border-white dark:border-slate-900" />
          </div>
          <div>
            <p className="text-sm font-semibold text-slate-900 dark:text-white group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
              {post.user?.name}
            </p>
            <p className="text-[11px] text-slate-400">
              @{post.user?.username} · {timeAgo(post.createdAt)}
            </p>
          </div>
        </Link>

        <div className="flex items-center gap-2">
          {category && (
            <span className="tag text-[10px]">
              {category.emoji} {category.label}
            </span>
          )}
          {isOwner && (
            <button
              onClick={handleDelete}
              className="btn-ghost p-1.5 text-slate-400 hover:text-red-500"
            >
              <TrashIcon className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Caption */}
      {post.caption && (
        <p className="px-4 pb-3 text-sm text-slate-700 dark:text-slate-300 leading-relaxed">
          {post.caption}
          {post.tags?.length > 0 && (
            <span className="block mt-1.5">
              {post.tags.map((t) => (
                <span key={t} className="text-brand-500 mr-1 text-xs">#{t}</span>
              ))}
            </span>
          )}
        </p>
      )}

      {/* Image */}
      {post.image && (
        <div
          className="relative cursor-zoom-in overflow-hidden bg-slate-100 dark:bg-slate-800 mx-4 rounded-xl mb-3"
          onClick={() => setShowImage(true)}
        >
          <img
            src={imgUrl(post.image)}
            className="w-full max-h-[480px] object-cover hover:scale-[1.01] transition-transform duration-300"
            alt="post"
            onError={(e) => (e.target.style.display = "none")}
          />
        </div>
      )}

      {/* Actions */}
      <div className="px-4 pb-3 flex items-center gap-1 border-t border-slate-100 dark:border-slate-800 pt-3">
        <button
          onClick={handleLike}
          disabled={loadingLike}
          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 active:scale-90 ${
            isLiked
              ? "text-red-500 bg-red-50 dark:bg-red-950/30"
              : "text-slate-500 hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-950/20"
          }`}
        >
          <HeartIcon className="w-4 h-4" filled={isLiked} />
          <span>{likes.length}</span>
        </button>

        <button
          onClick={() => setShowComments(!showComments)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-slate-500 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950/20 transition-all duration-150"
        >
          <CommentIcon className="w-4 h-4" />
          <span>{comments.length}</span>
        </button>

        <button
          onClick={handleSave}
          className={`ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-all duration-150 active:scale-90 ${
            saved
              ? "text-brand-500 bg-brand-50 dark:bg-brand-950/30"
              : "text-slate-400 hover:text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-950/20"
          }`}
        >
          <BookmarkIcon className="w-4 h-4" filled={saved} />
        </button>
      </div>

      {/* Comments section */}
      {showComments && (
        <div className="px-4 pb-4 border-t border-slate-100 dark:border-slate-800 pt-3 animate-fade-up">
          {/* Add comment */}
          <div className="flex gap-2 mb-3">
            <img
              src={imgUrl(user?.profilePic)}
              className="w-7 h-7 avatar flex-shrink-0 mt-0.5"
              onError={(e) => (e.target.src = "/default-avatar.png")}
            />
            <div className="flex-1 flex gap-2">
              <input
                value={commentText}
                onChange={(e) => setCommentText(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleComment()}
                placeholder="Add a comment..."
                className="input py-2 text-xs"
              />
              <button
                onClick={handleComment}
                disabled={!commentText.trim()}
                className="btn-primary px-3 py-1.5 text-xs"
              >
                Post
              </button>
            </div>
          </div>

          {/* Comment list */}
          <div className="space-y-2.5 max-h-52 overflow-y-auto">
            {comments.map((c) => (
              <div key={c._id} className="flex items-start gap-2 group">
                <img
                  src={imgUrl(c.user?.profilePic)}
                  className="w-6 h-6 avatar flex-shrink-0 mt-0.5"
                  onError={(e) => (e.target.src = "/default-avatar.png")}
                />
                <div className="flex-1 bg-slate-50 dark:bg-slate-800 rounded-xl px-3 py-2">
                  <span className="text-xs font-semibold text-slate-800 dark:text-slate-200 mr-1.5">
                    {c.user?.name}
                  </span>
                  <span className="text-xs text-slate-600 dark:text-slate-400">{c.text}</span>
                </div>
                {(c.user?._id === user?._id || isOwner) && (
                  <button
                    onClick={() => handleDeleteComment(c._id)}
                    className="opacity-0 group-hover:opacity-100 text-slate-300 hover:text-red-400 transition-all p-1"
                  >
                    <XIcon className="w-3 h-3" />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Image Lightbox */}
      {showImage && post.image && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setShowImage(false)}
        >
          <button className="absolute top-4 right-4 text-white/70 hover:text-white">
            <XIcon className="w-6 h-6" />
          </button>
          <img
            src={imgUrl(post.image)}
            className="max-w-full max-h-full rounded-xl object-contain"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}
    </article>
  );
}

function HeartIcon({ className, filled }) {
  return filled
    ? <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>
    : <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z"/></svg>;
}
function CommentIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>;
}
function BookmarkIcon({ className, filled }) {
  return filled
    ? <svg className={className} viewBox="0 0 24 24" fill="currentColor"><path d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/></svg>
    : <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/></svg>;
}
function TrashIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/></svg>;
}
function XIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12"/></svg>;
}
