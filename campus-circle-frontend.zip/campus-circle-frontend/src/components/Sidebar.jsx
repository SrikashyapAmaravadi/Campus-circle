import { NavLink, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";
import useAuthStore from "../store/useAuthStore";
import { imgUrl } from "../utils/helpers";

const navItems = [
  { to: "/",         icon: HomeIcon,       label: "Home" },
  { to: "/explore",  icon: ExploreIcon,    label: "Explore" },
  { to: "/events",   icon: EventIcon,      label: "Events" },
  { to: "/saved",    icon: SaveIcon,       label: "Saved" },
  { to: "/profile",  icon: ProfileIcon,    label: "Profile" },
];

export default function Sidebar({ onCreatePost }) {
  const { user, logout } = useAuthStore();
  const navigate = useNavigate();
  const [dark, setDark] = useState(() =>
    document.documentElement.classList.contains("dark")
  );

  useEffect(() => {
    dark
      ? document.documentElement.classList.add("dark")
      : document.documentElement.classList.remove("dark");
  }, [dark]);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <aside className="fixed top-0 left-0 h-screen w-64 flex flex-col bg-white dark:bg-slate-900 border-r border-slate-100 dark:border-slate-800 z-30 px-4 py-6">
      {/* Logo */}
      <div className="flex items-center gap-2.5 mb-8 px-2">
        <div className="w-9 h-9 rounded-xl bg-brand-500 flex items-center justify-center shadow-glow">
          <span className="text-white text-base font-bold font-display">CC</span>
        </div>
        <div>
          <p className="font-display font-bold text-base leading-tight text-slate-900 dark:text-white">Campus Circle</p>
          <p className="text-[10px] text-slate-400 dark:text-slate-500 leading-tight">Bennett University</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex flex-col gap-1 flex-1">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all duration-150 ` +
              (isActive
                ? "bg-brand-50 dark:bg-brand-950/60 text-brand-600 dark:text-brand-400"
                : "text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-slate-100")
            }
          >
            <Icon className="w-5 h-5 flex-shrink-0" />
            {label}
          </NavLink>
        ))}

        {/* Create Post CTA */}
        <button
          onClick={onCreatePost}
          className="mt-3 btn-primary w-full justify-center text-sm"
        >
          <PlusIcon className="w-4 h-4" />
          Create Post
        </button>
      </nav>

      {/* Bottom */}
      <div className="border-t border-slate-100 dark:border-slate-800 pt-4 space-y-1">
        <button
          onClick={() => setDark(!dark)}
          className="btn-ghost w-full justify-start text-sm"
        >
          {dark ? <SunIcon className="w-4 h-4" /> : <MoonIcon className="w-4 h-4" />}
          {dark ? "Light Mode" : "Dark Mode"}
        </button>
        <button
          onClick={handleLogout}
          className="btn-ghost w-full justify-start text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-950/30"
        >
          <LogoutIcon className="w-4 h-4" />
          Logout
        </button>

        {/* User mini card */}
        {user && (
          <div className="flex items-center gap-2.5 mt-3 p-2 rounded-xl bg-slate-50 dark:bg-slate-800">
            <img
              src={imgUrl(user.profilePic)}
              className="w-8 h-8 avatar flex-shrink-0"
              alt={user.name}
              onError={(e) => (e.target.src = "/default-avatar.png")}
            />
            <div className="min-w-0">
              <p className="text-xs font-semibold truncate text-slate-900 dark:text-white">{user.name}</p>
              <p className="text-[10px] text-slate-400 truncate">@{user.username}</p>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
}

// ── Icons ──────────────────────────────────────────────────
function HomeIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M3 9.75L12 3l9 6.75V21a.75.75 0 01-.75.75H15a.75.75 0 01-.75-.75v-4.5h-4.5V21a.75.75 0 01-.75.75H3.75A.75.75 0 013 21V9.75z"/></svg>;
}
function ExploreIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35"/></svg>;
}
function EventIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"/><path strokeLinecap="round" d="M16 2v4M8 2v4M3 10h18"/></svg>;
}
function SaveIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M5 5a2 2 0 012-2h10a2 2 0 012 2v16l-7-3.5L5 21V5z"/></svg>;
}
function ProfileIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path strokeLinecap="round" strokeLinejoin="round" d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/></svg>;
}
function PlusIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2.5} viewBox="0 0 24 24"><path strokeLinecap="round" d="M12 5v14M5 12h14"/></svg>;
}
function MoonIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" d="M21 12.79A9 9 0 1111.21 3 7 7 0 0021 12.79z"/></svg>;
}
function SunIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><path strokeLinecap="round" d="M12 1v2M12 21v2M4.22 4.22l1.42 1.42M18.36 18.36l1.42 1.42M1 12h2M21 12h2M4.22 19.78l1.42-1.42M18.36 5.64l1.42-1.42"/></svg>;
}
function LogoutIcon({ className }) {
  return <svg className={className} fill="none" stroke="currentColor" strokeWidth={2} viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1"/></svg>;
}
