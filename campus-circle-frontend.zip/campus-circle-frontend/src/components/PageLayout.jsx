import { useState } from "react";
import Sidebar from "./Sidebar";
import Navbar from "./Navbar";
import RightPanel from "./RightPanel";
import CreatePostModal from "./CreatePostModal";

export default function PageLayout({ children, hideRight = false, onPostCreated }) {
  const [showModal, setShowModal] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0d0f14]">
      <Sidebar onCreatePost={() => setShowModal(true)} />
      <Navbar />

      <div className="pl-64 pt-16 flex justify-center">
        <div className={`flex gap-6 w-full max-w-5xl px-6 py-6 ${hideRight ? "justify-center" : ""}`}>
          <main className="flex-1 min-w-0 max-w-xl">{children}</main>
          {!hideRight && <RightPanel />}
        </div>
      </div>

      <CreatePostModal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        onCreated={(post) => {
          setShowModal(false);
          onPostCreated?.(post);
        }}
      />
    </div>
  );
}
