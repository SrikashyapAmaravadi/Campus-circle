import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getSuggested, followUser, unfollowUser } from "../services/userService";
import { getEvents } from "../services/eventService";
import { imgUrl, timeAgo } from "../utils/helpers";
import { format } from "date-fns";
import toast from "react-hot-toast";

export default function RightPanel() {
  const [users, setUsers] = useState([]);
  const [events, setEvents] = useState([]);

  useEffect(() => {
    getSuggested().then(setUsers).catch(() => {});
    getEvents("?upcoming=true&limit=3").then((d) => setEvents(d.events || [])).catch(() => {});
  }, []);

  const toggleFollow = async (id) => {
    const user = users.find((u) => u._id === id);
    try {
      if (user.isFollowing) {
        await unfollowUser(id);
        toast.success("Unfollowed");
      } else {
        await followUser(id);
        toast.success("Following!");
      }
      setUsers((prev) =>
        prev.map((u) => u._id === id ? { ...u, isFollowing: !u.isFollowing } : u)
      );
    } catch {
      toast.error("Could not update follow");
    }
  };

  return (
    <aside className="hidden xl:flex flex-col gap-5 w-72 flex-shrink-0 py-6 pr-4">
      {/* Suggested Users */}
      <div className="card p-4">
        <h3 className="font-display font-semibold text-sm mb-3 text-slate-700 dark:text-slate-300">
          Suggested Students
        </h3>
        {users.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-4">No suggestions</p>
        ) : (
          <div className="space-y-3">
            {users.slice(0, 5).map((u) => (
              <div key={u._id} className="flex items-center gap-3">
                <Link to={`/profile/${u._id}`}>
                  <img
                    src={imgUrl(u.profilePic)}
                    className="w-9 h-9 avatar ring-2 ring-white dark:ring-slate-800 flex-shrink-0"
                    onError={(e) => (e.target.src = "/default-avatar.png")}
                  />
                </Link>
                <div className="flex-1 min-w-0">
                  <Link to={`/profile/${u._id}`}>
                    <p className="text-xs font-semibold truncate hover:text-brand-600 dark:hover:text-brand-400 transition-colors">
                      {u.name}
                    </p>
                  </Link>
                  <p className="text-[10px] text-slate-400 truncate">
                    {u.department || `@${u.username}`}
                  </p>
                </div>
                <button
                  onClick={() => toggleFollow(u._id)}
                  className={`text-xs px-2.5 py-1 rounded-lg font-medium transition-all duration-150 flex-shrink-0 ${
                    u.isFollowing
                      ? "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
                      : "bg-brand-500 text-white hover:bg-brand-600"
                  }`}
                >
                  {u.isFollowing ? "Following" : "Follow"}
                </button>
              </div>
            ))}
          </div>
        )}
        <Link to="/explore" className="block mt-3 text-xs text-brand-500 hover:text-brand-600 font-medium text-center">
          Find more students →
        </Link>
      </div>

      {/* Upcoming Events */}
      <div className="card p-4">
        <h3 className="font-display font-semibold text-sm mb-3 text-slate-700 dark:text-slate-300">
          Upcoming Events
        </h3>
        {events.length === 0 ? (
          <p className="text-xs text-slate-400 text-center py-4">No upcoming events</p>
        ) : (
          <div className="space-y-3">
            {events.map((ev) => (
              <Link key={ev._id} to="/events" className="block group">
                <div className="flex gap-3">
                  <div className="w-10 h-10 rounded-xl bg-brand-50 dark:bg-brand-950/40 flex flex-col items-center justify-center flex-shrink-0 group-hover:bg-brand-100 transition-colors">
                    <span className="text-[9px] text-brand-600 font-bold uppercase">
                      {format(new Date(ev.date), "MMM")}
                    </span>
                    <span className="text-sm text-brand-700 dark:text-brand-400 font-bold leading-none">
                      {format(new Date(ev.date), "d")}
                    </span>
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate group-hover:text-brand-600 dark:group-hover:text-brand-400 transition-colors">
                      {ev.title}
                    </p>
                    <p className="text-[10px] text-slate-400 truncate mt-0.5">
                      📍 {ev.location || "TBD"} · {ev.attendees?.length || 0} going
                    </p>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}
        <Link to="/events" className="block mt-3 text-xs text-brand-500 hover:text-brand-600 font-medium text-center">
          View all events →
        </Link>
      </div>

      {/* Footer */}
      <p className="text-[10px] text-slate-300 dark:text-slate-700 text-center px-2">
        © {new Date().getFullYear()} Campus Circle · Bennett University
      </p>
    </aside>
  );
}
