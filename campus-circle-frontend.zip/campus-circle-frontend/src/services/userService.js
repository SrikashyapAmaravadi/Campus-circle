import apiClient from "./apiClient";

export const getUserProfile  = (id)      => apiClient.get(`/users/${id}`).then(r => r.data);
export const getUserPosts    = (id)      => apiClient.get(`/users/${id}/posts`).then(r => r.data);
export const getSuggested    = ()        => apiClient.get("/users/suggested").then(r => r.data);
export const searchUsers     = (q)       => apiClient.get(`/users/search?q=${q}`).then(r => r.data);
export const followUser      = (id)      => apiClient.put(`/users/follow/${id}`).then(r => r.data);
export const unfollowUser    = (id)      => apiClient.put(`/users/unfollow/${id}`).then(r => r.data);
export const getSavedPosts   = ()        => apiClient.get("/users/saved").then(r => r.data);
