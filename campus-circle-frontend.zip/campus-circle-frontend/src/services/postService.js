import apiClient from "./apiClient";

export const getFeed       = (page = 1)  => apiClient.get(`/posts/feed?page=${page}`).then(r => r.data);
export const getPosts      = (page = 1)  => apiClient.get(`/posts?page=${page}`).then(r => r.data);
export const getPostById   = (id)        => apiClient.get(`/posts/${id}`).then(r => r.data);
export const searchPosts   = (q)         => apiClient.get(`/posts/search?q=${q}`).then(r => r.data);
export const createPost    = (form)      =>
  apiClient.post("/posts", form, { headers: { "Content-Type": "multipart/form-data" } }).then(r => r.data);
export const deletePost    = (id)        => apiClient.delete(`/posts/${id}`).then(r => r.data);
export const likePost      = (id)        => apiClient.put(`/posts/${id}/like`).then(r => r.data);
export const unlikePost    = (id)        => apiClient.put(`/posts/${id}/unlike`).then(r => r.data);
export const toggleSave    = (id)        => apiClient.put(`/posts/${id}/save`).then(r => r.data);
export const addComment    = (id, text)  => apiClient.post(`/posts/${id}/comments`, { text }).then(r => r.data);
export const deleteComment = (postId, commentId) =>
  apiClient.delete(`/posts/${postId}/comments/${commentId}`).then(r => r.data);
