import apiClient from "./apiClient";

export const loginUser    = (data) => apiClient.post("/auth/login", data).then(r => r.data);
export const registerUser = (data) => apiClient.post("/auth/register", data).then(r => r.data);
export const getMe        = ()     => apiClient.get("/auth/me").then(r => r.data);
export const updateProfile = (data) => apiClient.put("/auth/profile", data).then(r => r.data);
export const updateProfilePic = (form) =>
  apiClient.put("/auth/profile-pic", form, { headers: { "Content-Type": "multipart/form-data" } }).then(r => r.data);
export const updateCoverPic = (form) =>
  apiClient.put("/auth/cover-pic", form, { headers: { "Content-Type": "multipart/form-data" } }).then(r => r.data);
export const changePassword = (data) => apiClient.put("/auth/change-password", data).then(r => r.data);
