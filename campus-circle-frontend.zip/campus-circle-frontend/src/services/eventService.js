import apiClient from "./apiClient";

export const getEvents    = (params = "") => apiClient.get(`/events${params}`).then(r => r.data);
export const getEventById = (id)          => apiClient.get(`/events/${id}`).then(r => r.data);
export const createEvent  = (form)        =>
  apiClient.post("/events", form, { headers: { "Content-Type": "multipart/form-data" } }).then(r => r.data);
export const attendEvent  = (id)          => apiClient.put(`/events/${id}/attend`).then(r => r.data);
export const unattendEvent = (id)         => apiClient.put(`/events/${id}/unattend`).then(r => r.data);
