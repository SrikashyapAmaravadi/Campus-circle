import apiClient from "./apiClient";

export const getNotifications  = ()   => apiClient.get("/notifications").then(r => r.data);
export const getUnreadCount    = ()   => apiClient.get("/notifications/unread-count").then(r => r.data);
export const markAsRead        = (id) => apiClient.put(`/notifications/${id}/read`).then(r => r.data);
export const markAllAsRead     = ()   => apiClient.put("/notifications/mark-all-read").then(r => r.data);
export const deleteNotification = (id) => apiClient.delete(`/notifications/${id}`).then(r => r.data);
export const clearAll          = ()   => apiClient.delete("/notifications/all").then(r => r.data);
