import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import App from "./App";
import "./index.css";

ReactDOM.createRoot(document.getElementById("root")).render(
  <BrowserRouter>
    <App />
    <Toaster
      position="bottom-right"
      toastOptions={{
        style: {
          fontFamily: "Satoshi, sans-serif",
          borderRadius: "12px",
          fontSize: "14px",
          fontWeight: "500",
        },
        success: { iconTheme: { primary: "#3366ff", secondary: "#fff" } },
      }}
    />
  </BrowserRouter>
);
