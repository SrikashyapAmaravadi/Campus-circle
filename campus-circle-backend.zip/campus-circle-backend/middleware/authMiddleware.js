import jwt from "jsonwebtoken";
import User from "../models/User.js";

// ─── Protect: verify JWT and attach user ─────────────────────────────────────
export const protect = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({ message: "Not authorized, no token" });
    }

    const token = authHeader.split(" ")[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.id).select("-password");

    if (!user) {
      return res.status(401).json({ message: "User no longer exists" });
    }

    if (!user.isActive) {
      return res.status(401).json({ message: "Account has been deactivated" });
    }

    req.user = user;
    next();
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      return res.status(401).json({ message: "Token expired, please login again" });
    }
    return res.status(401).json({ message: "Not authorized, invalid token" });
  }
};

// ─── Admin only ───────────────────────────────────────────────────────────────
export const adminOnly = (req, res, next) => {
  if (req.user?.role !== "admin") {
    return res.status(403).json({ message: "Access denied: Admins only" });
  }
  next();
};

// ─── Faculty or Admin ─────────────────────────────────────────────────────────
export const facultyOrAdmin = (req, res, next) => {
  if (!["faculty", "admin"].includes(req.user?.role)) {
    return res.status(403).json({ message: "Access denied: Faculty or Admin only" });
  }
  next();
};

export default protect;
