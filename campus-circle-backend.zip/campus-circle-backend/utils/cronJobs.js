import cron from "node-cron";
import Event from "../models/Event.js";
import Notification from "../models/Notification.js";
import User from "../models/User.js";

// ─── Event Reminders: runs every hour ────────────────────────────────────────
// Sends a reminder notification to all users 24 hours before an event
cron.schedule("0 * * * *", async () => {
  try {
    const now = new Date();
    const in24hrs = new Date(now.getTime() + 24 * 60 * 60 * 1000);
    const in23hrs = new Date(now.getTime() + 23 * 60 * 60 * 1000);

    // Only fetch events that haven't had a reminder sent yet
    const upcomingEvents = await Event.find({
      date: { $gte: in23hrs, $lte: in24hrs },
      reminderSent: false,
      isActive: true,
    });

    if (upcomingEvents.length === 0) return;

    const users = await User.find({ isActive: true }, "_id");

    for (const event of upcomingEvents) {
      const notifications = users.map((user) => ({
        recipient: user._id,
        type: "reminder",
        event: event._id,
        message: `⏰ Reminder: "${event.title}" is happening tomorrow!`,
      }));

      await Notification.insertMany(notifications, { ordered: false });

      // Mark reminder as sent so it doesn't fire again
      await Event.findByIdAndUpdate(event._id, { reminderSent: true });

      console.log(`📢 Reminders sent for event: ${event.title}`);
    }
  } catch (error) {
    console.error("❌ Cron job error:", error.message);
  }
});

// ─── Cleanup: Delete read notifications older than 7 days ────────────────────
cron.schedule("0 0 * * *", async () => {
  try {
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const result = await Notification.deleteMany({
      isRead: true,
      createdAt: { $lt: sevenDaysAgo },
    });
    if (result.deletedCount > 0) {
      console.log(`🧹 Cleaned up ${result.deletedCount} old notifications`);
    }
  } catch (error) {
    console.error("❌ Cleanup cron error:", error.message);
  }
});

console.log("⏰ Cron jobs initialized");
