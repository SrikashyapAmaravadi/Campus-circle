import express from "express";
import {
  getUserProfile,
  followUser,
  unfollowUser,
  getFollowers,
  getFollowing,
  searchUsers,
  getSuggestedUsers,
  getUserPosts,
  getSavedPosts,
} from "../controllers/userController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// ─── Search & Suggestions ─────────────────────────────────────────────────────
router.get("/search", protect, searchUsers);
router.get("/suggested", protect, getSuggestedUsers);

// ─── Saved Posts ──────────────────────────────────────────────────────────────
router.get("/saved", protect, getSavedPosts);

// ─── Follow System ────────────────────────────────────────────────────────────
router.put("/follow/:id", protect, followUser);
router.put("/unfollow/:id", protect, unfollowUser);

// ─── User Profile & Social ────────────────────────────────────────────────────
// :id can be a MongoDB ObjectId OR a username
router.get("/:id", protect, getUserProfile);
router.get("/:id/followers", protect, getFollowers);
router.get("/:id/following", protect, getFollowing);
router.get("/:id/posts", protect, getUserPosts);

export default router;
