import express from "express";
import {
  getNotifications,
  markAsRead,
  markAllAsRead,
  deleteNotification,
  deleteAllNotifications,
  getUnreadCount,
} from "../controllers/notificationController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, getNotifications);
router.get("/unread-count", protect, getUnreadCount);

router.put("/mark-all-read", protect, markAllAsRead);
router.put("/:id/read", protect, markAsRead);

router.delete("/all", protect, deleteAllNotifications);
router.delete("/:id", protect, deleteNotification);

export default router;
