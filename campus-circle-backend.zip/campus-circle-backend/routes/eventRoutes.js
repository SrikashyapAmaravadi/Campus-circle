import express from "express";
import {
  createEvent,
  getEvents,
  getEventById,
  updateEvent,
  deleteEvent,
  attendEvent,
  unattendEvent,
} from "../controllers/eventController.js";
import { protect, facultyOrAdmin } from "../middleware/authMiddleware.js";
import { uploadSingle, handleUploadError } from "../middleware/uploadMiddleware.js";

const router = express.Router();

// ─── Public / General ─────────────────────────────────────────────────────────
router.get("/", getEvents);
router.get("/:id", protect, getEventById);

// ─── Create & Edit (Faculty or Admin only) ────────────────────────────────────
router.post("/", protect, facultyOrAdmin, uploadSingle, handleUploadError, createEvent);
router.put("/:id", protect, facultyOrAdmin, uploadSingle, handleUploadError, updateEvent);
router.delete("/:id", protect, facultyOrAdmin, deleteEvent);

// ─── RSVP ─────────────────────────────────────────────────────────────────────
router.put("/:id/attend", protect, attendEvent);
router.put("/:id/unattend", protect, unattendEvent);

export default router;
