import express from "express";
import {
  createPost,
  getPosts,
  getFeedPosts,
  getPostById,
  deletePost,
  likePost,
  unlikePost,
  addComment,
  deleteComment,
  toggleSavePost,
  searchPosts,
} from "../controllers/postController.js";
import { protect } from "../middleware/authMiddleware.js";
import { uploadSingle, handleUploadError } from "../middleware/uploadMiddleware.js";

const router = express.Router();

// ─── Explore & Feed ───────────────────────────────────────────────────────────
router.get("/", protect, getPosts);
router.get("/feed", protect, getFeedPosts);
router.get("/search", protect, searchPosts);

// ─── CRUD ─────────────────────────────────────────────────────────────────────
router.post("/", protect, uploadSingle, handleUploadError, createPost);
router.get("/:id", protect, getPostById);
router.delete("/:id", protect, deletePost);

// ─── Like System ──────────────────────────────────────────────────────────────
router.put("/:id/like", protect, likePost);
router.put("/:id/unlike", protect, unlikePost);

// ─── Save Post ────────────────────────────────────────────────────────────────
router.put("/:id/save", protect, toggleSavePost);

// ─── Comments ─────────────────────────────────────────────────────────────────
router.post("/:id/comments", protect, addComment);
router.delete("/:postId/comments/:commentId", protect, deleteComment);

export default router;
