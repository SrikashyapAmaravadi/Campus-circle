import express from "express";
import { body } from "express-validator";
import {
  registerUser,
  loginUser,
  getMe,
  updateProfile,
  updateProfilePic,
  updateCoverPic,
  changePassword,
} from "../controllers/authController.js";
import { protect } from "../middleware/authMiddleware.js";
import { uploadSingle, handleUploadError } from "../middleware/uploadMiddleware.js";
import validate from "../middleware/validate.js";

const router = express.Router();

// ─── Validation Rules ─────────────────────────────────────────────────────────
const registerRules = [
  body("name").trim().notEmpty().withMessage("Name is required"),
  body("username")
    .trim()
    .notEmpty()
    .withMessage("Username is required")
    .matches(/^[a-z0-9_.]+$/)
    .withMessage("Username can only contain letters, numbers, dots, and underscores"),
  body("email").isEmail().withMessage("Valid email is required"),
  body("password")
    .isLength({ min: 6 })
    .withMessage("Password must be at least 6 characters"),
];

const loginRules = [
  body("email").isEmail().withMessage("Valid email is required"),
  body("password").notEmpty().withMessage("Password is required"),
];

// ─── Public Routes ────────────────────────────────────────────────────────────
router.post("/register", registerRules, validate, registerUser);
router.post("/login", loginRules, validate, loginUser);

// ─── Protected Routes ─────────────────────────────────────────────────────────
router.get("/me", protect, getMe);
router.put("/profile", protect, updateProfile);
router.put("/profile-pic", protect, uploadSingle, handleUploadError, updateProfilePic);
router.put("/cover-pic", protect, uploadSingle, handleUploadError, updateCoverPic);
router.put("/change-password", protect, changePassword);

export default router;
