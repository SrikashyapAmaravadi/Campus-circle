# 🎓 Campus Circle — Backend API

A modern RESTful API for a university social media platform. Built with Node.js, Express, and MongoDB.

---

## 🗂 Project Structure

```
campus-circle-backend/
├── config/
│   └── db.js                   # MongoDB connection
├── controllers/
│   ├── authController.js       # Register, login, profile
│   ├── userController.js       # Follow, search, profile
│   ├── postController.js       # CRUD, likes, comments, saves
│   ├── eventController.js      # CRUD, RSVP
│   └── notificationController.js
├── middleware/
│   ├── authMiddleware.js       # JWT protect, role guards
│   ├── uploadMiddleware.js     # Multer image upload
│   └── validate.js             # express-validator helper
├── models/
│   ├── User.js
│   ├── Post.js
│   ├── Event.js
│   └── Notification.js
├── routes/
│   ├── authRoutes.js
│   ├── userRoutes.js
│   ├── postRoutes.js
│   ├── eventRoutes.js
│   └── notificationRoutes.js
├── utils/
│   ├── generateToken.js
│   ├── apiError.js
│   └── cronJobs.js             # Reminders + cleanup
├── uploads/                    # Served as static files
├── .env.example
├── server.js
└── package.json
```

---

## ⚙️ Setup

```bash
npm install
cp .env.example .env
# Fill in MONGO_URI and JWT_SECRET in .env
npm run dev
```

---

## 🔐 Authentication

All protected routes require a Bearer token in the Authorization header:

```
Authorization: Bearer <token>
```

---

## 📡 API Reference

### Auth — `/api/auth`

| Method | Route             | Auth | Description                  |
|--------|-------------------|------|------------------------------|
| POST   | /register         | ❌   | Register new user            |
| POST   | /login            | ❌   | Login and receive token      |
| GET    | /me               | ✅   | Get current user             |
| PUT    | /profile          | ✅   | Update name, bio, department |
| PUT    | /profile-pic      | ✅   | Upload profile picture       |
| PUT    | /cover-pic        | ✅   | Upload cover picture         |
| PUT    | /change-password  | ✅   | Change password              |

**Register body:**
```json
{
  "name": "Rahul Sharma",
  "username": "rahul.sharma",
  "email": "rahul@university.edu",
  "password": "securepass",
  "department": "Computer Science",
  "year": "3rd Year"
}
```

---

### Users — `/api/users`

| Method | Route               | Auth | Description                          |
|--------|---------------------|------|--------------------------------------|
| GET    | /search?q=&department=&year= | ✅ | Search users                |
| GET    | /suggested          | ✅   | Get suggested users to follow        |
| GET    | /saved              | ✅   | Get current user's saved posts       |
| PUT    | /follow/:id         | ✅   | Follow a user                        |
| PUT    | /unfollow/:id       | ✅   | Unfollow a user                      |
| GET    | /:id                | ✅   | Get user profile (by ID or username) |
| GET    | /:id/followers      | ✅   | Get user's followers                 |
| GET    | /:id/following      | ✅   | Get user's following                 |
| GET    | /:id/posts          | ✅   | Get user's posts                     |

---

### Posts — `/api/posts`

| Method | Route                        | Auth | Description                      |
|--------|------------------------------|------|----------------------------------|
| GET    | /?category=&page=&limit=     | ✅   | Get all posts (explore)          |
| GET    | /feed                        | ✅   | Get posts from followed users    |
| GET    | /search?q=&category=&tag=    | ✅   | Search posts                     |
| POST   | /                            | ✅   | Create post (image via form-data)|
| GET    | /:id                         | ✅   | Get single post                  |
| DELETE | /:id                         | ✅   | Delete post (owner or admin)     |
| PUT    | /:id/like                    | ✅   | Like a post                      |
| PUT    | /:id/unlike                  | ✅   | Unlike a post                    |
| PUT    | /:id/save                    | ✅   | Toggle save/unsave a post        |
| POST   | /:id/comments                | ✅   | Add a comment                    |
| DELETE | /:postId/comments/:commentId | ✅   | Delete a comment                 |

**Create Post (multipart/form-data):**
```
image     — file (jpg, jpeg, png, webp, max 5MB)
caption   — string (optional, max 1000 chars)
category  — general | academic | event | club | announcement | lost-found | marketplace
tags      — comma-separated string e.g. "cs, exam, tips"
```

---

### Events — `/api/events`

| Method | Route            | Auth           | Description                           |
|--------|------------------|----------------|---------------------------------------|
| GET    | /?category=&upcoming=true | ❌  | Get all events                        |
| GET    | /:id             | ✅             | Get single event                      |
| POST   | /                | ✅ faculty/admin| Create event (notifies all users)     |
| PUT    | /:id             | ✅ faculty/admin| Update event                          |
| DELETE | /:id             | ✅ faculty/admin| Delete event                          |
| PUT    | /:id/attend      | ✅             | RSVP to event                         |
| PUT    | /:id/unattend    | ✅             | Cancel RSVP                           |

**Event categories:** `academic | cultural | sports | workshop | seminar | fest | club | other`

---

### Notifications — `/api/notifications`

| Method | Route             | Auth | Description                    |
|--------|-------------------|------|--------------------------------|
| GET    | /                 | ✅   | Get all notifications (paged)  |
| GET    | /unread-count     | ✅   | Get unread count only          |
| PUT    | /mark-all-read    | ✅   | Mark all as read               |
| PUT    | /:id/read         | ✅   | Mark one as read               |
| DELETE | /all              | ✅   | Clear all notifications        |
| DELETE | /:id              | ✅   | Delete a notification          |

---

## 👤 User Roles

| Role    | Can create events | Can delete any post | Notes                   |
|---------|-------------------|---------------------|-------------------------|
| student | ❌                | ❌                  | Default role            |
| faculty | ✅                | ❌                  | Event management access |
| admin   | ✅                | ✅                  | Full access             |

---

## ⏰ Cron Jobs

| Schedule   | Task                                          |
|------------|-----------------------------------------------|
| Every hour | Send 24h reminder notifications for events    |
| Every day  | Delete read notifications older than 7 days   |

---

## 🧱 Models Overview

### User
`name · username · email · password · profilePic · coverPic · bio · department · year · rollNumber · role · isVerified · followers · following · savedPosts · isActive`

### Post
`user · caption · image · category · tags · likes · comments · saves · isArchived`

### Event
`title · description · date · endDate · location · coverImage · category · organizer · createdBy · attendees · maxAttendees · reminderSent · isActive`

### Notification
`recipient · sender · type · post · event · message · isRead`
**Types:** `like | comment | follow | event | reminder | mention | system`
Auto-expires after 30 days (MongoDB TTL index).
