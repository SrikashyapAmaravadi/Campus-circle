import mongoose from "mongoose";

const eventSchema = new mongoose.Schema(
  {
    title: {
      type: String,
      required: [true, "Event title is required"],
      trim: true,
      maxlength: [100, "Title cannot exceed 100 characters"],
    },

    description: {
      type: String,
      default: "",
      maxlength: [2000, "Description cannot exceed 2000 characters"],
    },

    date: {
      type: Date,
      required: [true, "Event date is required"],
    },

    endDate: {
      type: Date,
      default: null,
    },

    location: {
      type: String,
      default: "",
      trim: true,
    },

    coverImage: {
      type: String,
      default: "",
    },

    category: {
      type: String,
      enum: ["academic", "cultural", "sports", "workshop", "seminar", "fest", "club", "other"],
      default: "other",
    },

    organizer: {
      type: String,
      default: "",
      trim: true,
    },

    createdBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },

    attendees: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],

    maxAttendees: {
      type: Number,
      default: null, // null = unlimited
    },

    isActive: {
      type: Boolean,
      default: true,
    },

    reminderSent: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true }
);

eventSchema.index({ date: 1 });
eventSchema.index({ category: 1 });
eventSchema.index({ title: "text", description: "text" });

export default mongoose.model("Event", eventSchema);
