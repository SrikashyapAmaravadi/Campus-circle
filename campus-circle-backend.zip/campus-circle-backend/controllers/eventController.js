import Event from "../models/Event.js";
import Notification from "../models/Notification.js";
import User from "../models/User.js";

// ─── Create Event ─────────────────────────────────────────────────────────────
export const createEvent = async (req, res) => {
  try {
    const { title, description, date, endDate, location, category, organizer, maxAttendees } = req.body;

    const event = await Event.create({
      title,
      description,
      date,
      endDate: endDate || null,
      location,
      category: category || "other",
      organizer: organizer || req.user.name,
      maxAttendees: maxAttendees || null,
      coverImage: req.file ? `/uploads/${req.file.filename}` : "",
      createdBy: req.user._id,
    });

    // Notify ALL active users about new event
    const users = await User.find({ isActive: true, _id: { $ne: req.user._id } }, "_id");

    const notifications = users.map((user) => ({
      recipient: user._id,
      sender: req.user._id,
      type: "event",
      event: event._id,
      message: `📅 New event: "${title}"`,
    }));

    if (notifications.length > 0) {
      await Notification.insertMany(notifications, { ordered: false });
    }

    const populated = await Event.findById(event._id).populate(
      "createdBy",
      "name username profilePic"
    );

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get All Events ───────────────────────────────────────────────────────────
export const getEvents = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const { category, upcoming } = req.query;

    const filter = { isActive: true };
    if (category) filter.category = category;
    if (upcoming === "true") filter.date = { $gte: new Date() };

    const [events, total] = await Promise.all([
      Event.find(filter)
        .populate("createdBy", "name username profilePic")
        .sort({ date: 1 })
        .skip(skip)
        .limit(limit),
      Event.countDocuments(filter),
    ]);

    res.json({ events, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Single Event ─────────────────────────────────────────────────────────
export const getEventById = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id)
      .populate("createdBy", "name username profilePic")
      .populate("attendees", "name username profilePic department");

    if (!event || !event.isActive) {
      return res.status(404).json({ message: "Event not found" });
    }

    const isAttending = req.user
      ? event.attendees.some((a) => a._id.toString() === req.user._id.toString())
      : false;

    res.json({ ...event.toObject(), isAttending });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── RSVP / Attend Event ──────────────────────────────────────────────────────
export const attendEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event || !event.isActive) {
      return res.status(404).json({ message: "Event not found" });
    }

    const alreadyAttending = event.attendees.some(
      (id) => id.toString() === req.user._id.toString()
    );

    if (alreadyAttending) {
      return res.status(400).json({ message: "Already registered for this event" });
    }

    if (event.maxAttendees && event.attendees.length >= event.maxAttendees) {
      return res.status(400).json({ message: "Event is full" });
    }

    event.attendees.push(req.user._id);
    await event.save();

    res.json({ message: "Successfully registered for event", attendeesCount: event.attendees.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Cancel RSVP ─────────────────────────────────────────────────────────────
export const unattendEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });

    event.attendees = event.attendees.filter(
      (id) => id.toString() !== req.user._id.toString()
    );
    await event.save();

    res.json({ message: "Registration cancelled", attendeesCount: event.attendees.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Update Event ─────────────────────────────────────────────────────────────
export const updateEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const isOwner = event.createdBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === "admin";

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: "Not authorized" });
    }

    const updates = { ...req.body };
    if (req.file) updates.coverImage = `/uploads/${req.file.filename}`;

    const updated = await Event.findByIdAndUpdate(req.params.id, updates, {
      new: true,
      runValidators: true,
    }).populate("createdBy", "name username profilePic");

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Delete Event ─────────────────────────────────────────────────────────────
export const deleteEvent = async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) return res.status(404).json({ message: "Event not found" });

    const isOwner = event.createdBy.toString() === req.user._id.toString();
    const isAdmin = req.user.role === "admin";

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await event.deleteOne();
    res.json({ message: "Event deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
