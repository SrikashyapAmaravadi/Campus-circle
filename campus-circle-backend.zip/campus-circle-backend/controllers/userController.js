import User from "../models/User.js";
import Post from "../models/Post.js";
import Notification from "../models/Notification.js";

// ─── Get User Profile ─────────────────────────────────────────────────────────
export const getUserProfile = async (req, res) => {
  try {
    // Support lookup by ID or username
    const query = req.params.id.match(/^[0-9a-fA-F]{24}$/)
      ? { _id: req.params.id }
      : { username: req.params.id };

    const user = await User.findOne(query)
      .select("-password")
      .populate("followers", "name username profilePic")
      .populate("following", "name username profilePic");

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const postsCount = await Post.countDocuments({ user: user._id, isArchived: false });
    const isFollowing = user.followers.some(
      (f) => f._id.toString() === req.user._id.toString()
    );

    res.json({
      user,
      postsCount,
      followersCount: user.followers.length,
      followingCount: user.following.length,
      isFollowing,
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Follow User ──────────────────────────────────────────────────────────────
export const followUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    const currentId = req.user._id.toString();

    if (targetId === currentId) {
      return res.status(400).json({ message: "You cannot follow yourself" });
    }

    const [target, current] = await Promise.all([
      User.findById(targetId),
      User.findById(currentId),
    ]);

    if (!target) return res.status(404).json({ message: "User not found" });

    if (target.followers.includes(currentId)) {
      return res.status(400).json({ message: "Already following this user" });
    }

    // Add follow relationship
    target.followers.push(currentId);
    current.following.push(targetId);
    await Promise.all([target.save(), current.save()]);

    // Send follow notification
    await Notification.create({
      recipient: targetId,
      sender: currentId,
      type: "follow",
      message: `${current.name} started following you`,
    });

    res.json({ message: "Followed successfully", followersCount: target.followers.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Unfollow User ────────────────────────────────────────────────────────────
export const unfollowUser = async (req, res) => {
  try {
    const targetId = req.params.id;
    const currentId = req.user._id.toString();

    const [target, current] = await Promise.all([
      User.findById(targetId),
      User.findById(currentId),
    ]);

    if (!target) return res.status(404).json({ message: "User not found" });

    target.followers = target.followers.filter((id) => id.toString() !== currentId);
    current.following = current.following.filter((id) => id.toString() !== targetId);

    await Promise.all([target.save(), current.save()]);

    res.json({ message: "Unfollowed successfully", followersCount: target.followers.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Followers ────────────────────────────────────────────────────────────
export const getFollowers = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate(
      "followers",
      "name username profilePic bio department year"
    );
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user.followers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Following ────────────────────────────────────────────────────────────
export const getFollowing = async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate(
      "following",
      "name username profilePic bio department year"
    );
    if (!user) return res.status(404).json({ message: "User not found" });
    res.json(user.following);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Search Users ─────────────────────────────────────────────────────────────
export const searchUsers = async (req, res) => {
  try {
    const { q, department, year } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const filter = { isActive: true, _id: { $ne: req.user._id } };

    if (q) {
      filter.$or = [
        { name: { $regex: q, $options: "i" } },
        { username: { $regex: q, $options: "i" } },
        { bio: { $regex: q, $options: "i" } },
      ];
    }

    if (department) filter.department = { $regex: department, $options: "i" };
    if (year) filter.year = year;

    const [users, total] = await Promise.all([
      User.find(filter)
        .select("name username profilePic bio department year followers")
        .skip(skip)
        .limit(limit),
      User.countDocuments(filter),
    ]);

    const usersWithFollowStatus = users.map((u) => ({
      ...u.toObject(),
      isFollowing: u.followers.some((f) => f.toString() === req.user._id.toString()),
      followersCount: u.followers.length,
    }));

    res.json({
      users: usersWithFollowStatus,
      total,
      page,
      pages: Math.ceil(total / limit),
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Suggested Users ──────────────────────────────────────────────────────
export const getSuggestedUsers = async (req, res) => {
  try {
    const currentUser = await User.findById(req.user._id);

    // Suggest users not already followed, same department
    const suggested = await User.find({
      _id: { $ne: req.user._id, $nin: currentUser.following },
      isActive: true,
    })
      .select("name username profilePic bio department year followers")
      .limit(8)
      .sort({ followers: -1 }); // trending first

    res.json(suggested);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get User Posts ───────────────────────────────────────────────────────────
export const getUserPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 12;
    const skip = (page - 1) * limit;

    const [posts, total] = await Promise.all([
      Post.find({ user: req.params.id, isArchived: false })
        .populate("user", "name username profilePic")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Post.countDocuments({ user: req.params.id, isArchived: false }),
    ]);

    res.json({ posts, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Saved Posts ──────────────────────────────────────────────────────────
export const getSavedPosts = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).populate({
      path: "savedPosts",
      populate: { path: "user", select: "name username profilePic" },
      options: { sort: { createdAt: -1 } },
    });

    res.json(user.savedPosts);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
