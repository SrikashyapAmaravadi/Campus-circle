import Post from "../models/Post.js";
import User from "../models/User.js";
import Notification from "../models/Notification.js";

// ─── Create Post ──────────────────────────────────────────────────────────────
export const createPost = async (req, res) => {
  try {
    const { caption, category, tags } = req.body;

    if (!req.file && !caption?.trim()) {
      return res.status(400).json({ message: "A caption or image is required" });
    }

    const parsedTags = tags
      ? tags.split(",").map((t) => t.trim().toLowerCase()).filter(Boolean)
      : [];

    const post = await Post.create({
      user: req.user._id,
      caption: caption || "",
      image: req.file ? `/uploads/${req.file.filename}` : null,
      category: category || "general",
      tags: parsedTags,
    });

    const populated = await Post.findById(post._id).populate(
      "user",
      "name username profilePic"
    );

    res.status(201).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get All Posts (Explore) ──────────────────────────────────────────────────
export const getPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;
    const { category } = req.query;

    const filter = { isArchived: false };
    if (category) filter.category = category;

    const [posts, total] = await Promise.all([
      Post.find(filter)
        .populate("user", "name username profilePic department")
        .populate("comments.user", "name username profilePic")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Post.countDocuments(filter),
    ]);

    res.json({ posts, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Feed (Following only) ────────────────────────────────────────────────
export const getFeedPosts = async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const currentUser = await User.findById(req.user._id);
    const feedUsers = [...currentUser.following, req.user._id];

    const [posts, total] = await Promise.all([
      Post.find({ user: { $in: feedUsers }, isArchived: false })
        .populate("user", "name username profilePic department")
        .populate("comments.user", "name username profilePic")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Post.countDocuments({ user: { $in: feedUsers }, isArchived: false }),
    ]);

    res.json({ posts, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Get Single Post ──────────────────────────────────────────────────────────
export const getPostById = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id)
      .populate("user", "name username profilePic department")
      .populate("comments.user", "name username profilePic")
      .populate("likes", "name username profilePic");

    if (!post || post.isArchived) {
      return res.status(404).json({ message: "Post not found" });
    }

    res.json(post);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Delete Post ──────────────────────────────────────────────────────────────
export const deletePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);

    if (!post) return res.status(404).json({ message: "Post not found" });

    const isOwner = post.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role === "admin";

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ message: "Not authorized" });
    }

    await post.deleteOne();
    res.json({ message: "Post deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Like Post ────────────────────────────────────────────────────────────────
export const likePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const userId = req.user._id.toString();
    const alreadyLiked = post.likes.some((id) => id.toString() === userId);

    if (alreadyLiked) {
      return res.status(400).json({ message: "Post already liked" });
    }

    post.likes.push(req.user._id);
    await post.save();

    // Notify post owner (not if liking own post)
    if (post.user.toString() !== userId) {
      await Notification.create({
        recipient: post.user,
        sender: req.user._id,
        type: "like",
        post: post._id,
        message: `${req.user.name} liked your post`,
      });
    }

    res.json({ likesCount: post.likes.length, liked: true });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Unlike Post ──────────────────────────────────────────────────────────────
export const unlikePost = async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    post.likes = post.likes.filter(
      (id) => id.toString() !== req.user._id.toString()
    );
    await post.save();

    res.json({ likesCount: post.likes.length, liked: false });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Add Comment ──────────────────────────────────────────────────────────────
export const addComment = async (req, res) => {
  try {
    const { text } = req.body;
    if (!text?.trim()) {
      return res.status(400).json({ message: "Comment text is required" });
    }

    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found" });

    post.comments.push({ user: req.user._id, text });
    await post.save();

    // Notify post owner (not if commenting on own post)
    if (post.user.toString() !== req.user._id.toString()) {
      await Notification.create({
        recipient: post.user,
        sender: req.user._id,
        type: "comment",
        post: post._id,
        message: `${req.user.name} commented on your post`,
      });
    }

    const updated = await Post.findById(req.params.id)
      .populate("user", "name username profilePic")
      .populate("comments.user", "name username profilePic");

    res.json(updated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Delete Comment ───────────────────────────────────────────────────────────
export const deleteComment = async (req, res) => {
  try {
    const { postId, commentId } = req.params;

    const post = await Post.findById(postId);
    if (!post) return res.status(404).json({ message: "Post not found" });

    const comment = post.comments.id(commentId);
    if (!comment) return res.status(404).json({ message: "Comment not found" });

    const isCommentOwner = comment.user.toString() === req.user._id.toString();
    const isPostOwner = post.user.toString() === req.user._id.toString();
    const isAdmin = req.user.role === "admin";

    if (!isCommentOwner && !isPostOwner && !isAdmin) {
      return res.status(403).json({ message: "Not authorized" });
    }

    post.comments = post.comments.filter((c) => c._id.toString() !== commentId);
    await post.save();

    res.json({ message: "Comment deleted", commentsCount: post.comments.length });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Save / Unsave Post ───────────────────────────────────────────────────────
export const toggleSavePost = async (req, res) => {
  try {
    const postId = req.params.id;
    const user = await User.findById(req.user._id);

    const alreadySaved = user.savedPosts.includes(postId);

    if (alreadySaved) {
      user.savedPosts = user.savedPosts.filter((id) => id.toString() !== postId);
      await user.save();
      return res.json({ saved: false, message: "Post removed from saved" });
    }

    user.savedPosts.push(postId);
    await user.save();
    res.json({ saved: true, message: "Post saved successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// ─── Search Posts ─────────────────────────────────────────────────────────────
export const searchPosts = async (req, res) => {
  try {
    const { q, category, tag } = req.query;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const filter = { isArchived: false };
    if (category) filter.category = category;
    if (tag) filter.tags = tag.toLowerCase();
    if (q) filter.$text = { $search: q };

    const [posts, total] = await Promise.all([
      Post.find(filter)
        .populate("user", "name username profilePic department")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      Post.countDocuments(filter),
    ]);

    res.json({ posts, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
